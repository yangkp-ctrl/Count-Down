### 桌面倒计时插件

![image](https://cdn.jsdelivr.net/gh/yuzh0816/Count-Down@1.0/docs/1.png)

![image](https://cdn.jsdelivr.net/gh/yuzh0816/Count-Down@1.0/docs/2.png)

### 后续会不断跟进

现在已有：

- 2020普陀一模倒计时